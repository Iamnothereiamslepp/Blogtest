---
id: github-other
slug: github-other
title: .github 其他文件
date: 2021-10-01
authors: kuizuo
tags: [github]
keywords: [github]
---

<!-- truncate -->

### ISSUE_TEMPLATE

**issues 默认模版**

[Configuring issue templates for your repository - GitHub Docs](https://docs.github.com/en/communities/using-templates-to-encourage-useful-issues-and-pull-requests/configuring-issue-templates-for-your-repository)

### CODEOWNERS

**仓库代码拥有者。用于合并请求批准**

```
# https://help.github.com/articles/about-codeowners/

* @kuizuo
```

### FUNDING.yml

**配置赞助者按钮**

[在仓库中显示赞助者按钮 - GitHub Docs](https://docs.github.com/cn/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/displaying-a-sponsor-button-in-your-repository#about-funding-files)

### CONTRIBUTING.md

**贡献指南**