---
id: js-code-obfuscation-and-reverse
slug: /js-code-obfuscation-and-reverse
title: JS代码混淆与还原
authors: kuizuo
tags: [javascript, deobfuscator]
keywords: [javascript, deobfuscator]
---

<!-- truncate -->

[JS 代码之还原](/blog/js-code-deobfuscator)

[JS 代码之混淆](/blog/js-code-obfuscator)
