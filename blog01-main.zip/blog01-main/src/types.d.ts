/// <reference types="@docusaurus/plugin-ideal-image" />
/// <reference types="@types/gtag.js" />
/// <reference types="@docusaurus/module-type-aliases" />
/// <reference types="@docusaurus/theme-classic" />
